<?php
/*
 * Plugin Name: Blog Widget
 * Description: Blog Widget is RSS reader widget, which displays the RSS feeds in the widget . 
 */
function blog_defaults(){
    return array(
        'title' => '',
        'urls' => '',
        'count' => 5,
        'show_date' => 0,
  );
}

// The main RSS Parser
function rss_parser($instance){
    $instance = wp_parse_args($instance, blog_defaults());
    $url = stripslashes($instance['urls']);
    $count = intval($instance['count']);
    $show_date = intval($instance['show_date']);
    if(empty($url)){
        return '';
    }
     $rss = fetch_feed($url);
      
        if( method_exists( $rss, 'enable_order_by_date' ) ){
            $rss->enable_order_by_date(false);
        }
            $maxitems = $rss->get_item_quantity($count);
            $rss_items = $rss->get_items(0, $maxitems); 
            $rss_title = esc_attr(strip_tags($rss->get_title()));
            $rss_desc = esc_attr(strip_tags($rss->get_description()));
                        $j=1;
            // Loop through each feed item
            foreach ($rss_items as $item){
                // Get the link
                $link = $item->get_link();
                while ( stristr($link, 'http') != $link ){ $link = substr($link, 1); }
                $link = esc_url(strip_tags($link));
                
                // Get the item title
                $title = esc_attr(strip_tags($item->get_title()));
                if ( empty($title) )
                    $title = __('No Title');
                // Get the Subject for icon access
                $subject=$item->get_item_tags(SIMPLEPIE_NAMESPACE_DC_11, 'subject');
                // Get the article type
                $article=$item->get_item_tags('http://purl.org/rss/1.0/modules/prism/', 'section');
                // Get the date
                $date = $item->get_date('j F Y');
              
                echo "\n\n\t";
              
             /* ************** Display the feed items Html************** */

                // Display the feed items
                 echo '<div class="blog-item ">'; //design needed 
                 echo '<div class="blog-article"><strong>'. $article[0]["data"]. '</strong></div>';  //design needed 
                 echo '<div class="blog-link"><a href="' . $link . '"  title="Posted on ' . $date . '">' . $title . '</a></div>'; //design needed 
                 echo '<time class="blog-date">' . $date . '</time>'; //design needed 
                 $val=$subject[0]["data"];
                 if (strpos($val, 'Open access') !== false) {
                  echo '<img src="https://resources.bmj.com/repository/journals-network-project/images/wordpress/icon-open-access.svg" width="20px" height="20px"/> '; //design needed 
                       }
                if (strpos($val, "Editor's choice") !== false) {
                  echo '<img src="https://resources.bmj.com/repository/journals-network-project/images/wordpress/icon-text-editors-choice.svg" width="50px" height="50px"/> '; //design needed 
                   } 
                 echo '</div>';
              
            /* ************** Display the feed items Html Ends Here ************** */
                
                $j++;
            }
       // }
        
        if ( ! is_wp_error($rss) )
            $rss->__destruct();
        
        unset($rss);
       }

class blog_rss_reader_widget extends WP_Widget{
    // Initialize
    public function __construct(){
        $widget_ops = array(
            'classname' => 'widget_blog_rss_reader',  );
        $control_ops = array('width' => 300, 'height' => 500);
        parent::__construct('blog_rss_reader', 'Latest Content/Most Popular', $widget_ops, $control_ops);
    }
    
    // Display the Widget
    public function widget($args, $instance){
        extract($args);
        if(empty($instance['title'])){
            $title = '';
        }else{
            $title = $before_title . apply_filters('widget_title', $instance['title'], $instance, $this->id_base) . $after_title;
        }
         echo $before_widget  .'<div class="custom-title">' . $title.'</div>';  //design needed 
         rss_parser($instance);
         echo $after_widget;
    }
    
    // Save settings
    public function update($new_instance, $old_instance){
        $instance = $old_instance;
        $instance['title'] = stripslashes($new_instance['title']);
        $instance['urls'] = stripslashes($new_instance['urls']);
        $instance['count'] = intval($new_instance['count']);
        $instance['show_date'] = intval($new_instance['show_date']);
        return $instance;
    }
    
    //  Widget form
    public function form($instance){
        
        $instance = wp_parse_args((array) $instance, blog_defaults());
        $title = htmlspecialchars($instance['title']);
        $url = htmlspecialchars($instance['urls']);
        $count = intval($instance['count']);
        $show_date = intval($instance['show_date']);
       
         ?>

        <div class="blog_settings">
        <table width="100%" height="72" border="0">
        <tr>
          <td width="13%" height="33"><label for="<?php echo $this->get_field_id('title'); ?>">Title: </label></td>
          <td width="87%"><input id="<?php echo $this->get_field_id('title');?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" class="widefat"/></td>
        </tr>
        <tr>
            <td><label for="<?php echo $this->get_field_id('urls'); ?>">URL: </label></td>
            <td><input id="<?php echo $this->get_field_id('urls');?>" name="<?php echo $this->get_field_name('urls'); ?>" type="text" value="<?php echo $url; ?>" class="widefat"/>
            </td>

        </tr>
        <tr>
            <td width="28%"><label for="<?php echo $this->get_field_id('count');?>">Total items to show:</label></td>
            <td width="25%"><input id="<?php echo $this->get_field_id('count');?>" name="<?php echo $this->get_field_name('count'); ?>" type="number" value="<?php echo $count; ?>" class="widefat" title="No of feed items to parse"/></td>
        </tr>
        </table>
        </div>
        
        <?php
    }
}

function blog_rss_reader_init(){
    register_widget('blog_rss_reader_widget');
}
add_action('widgets_init', 'blog_rss_reader_init');
wp_enqueue_style( 'myCSS', plugins_url( '/css/style.css', __FILE__ ) );
?>